# TrafficTelligence: Advanced Traffic Volume Estimation With Machine Learning

This project estimates traffic volume using historical data and machine learning techniques.
